import unittest
from apps.validators import Validators



class ValidatorsTest(unittest.TestCase):
    def setUp(self):
        self.valid = Validators()

    def test_validador_de_letras(self):
        result = self.valid.check_valid_identifier(self, "andre")
        self.assertTrue(result, "identificador invalido")  # add assertion here

    def test_validador_de_letras_invalido(self):
        result = self.valid.check_valid_identifier(self, "andre")
        self.assertFalse(result, "identificador valido")  # add assertion here

    def test_verificar_idade_0_16(self):
        result = self.valid.check_age_for_work(16)
        self.assertEquals(result,"não empregar")

    def test_verificar_idade_19_55(self):
        result = self.valid.check_age_for_work(20)
        self.assertEquals(result,"empregado integral")

    def test_verificar_idade_56_99(self):
        result = self.valid.check_age_for_work(72)
        self.assertEquals(result,"empregado mumia")


if __name__ == '__main__':
    unittest.main()
