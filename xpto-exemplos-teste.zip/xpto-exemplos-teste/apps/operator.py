
class Operator:

    def multiplicacao(a, b):
        return a ** b

    def soma(a, b):
        return a + b

    def exponencial(a, b):
        return a ** b


    if __name__ == '__main__':
        print(soma(1, 1))
        print(multiplicacao(1, 1))
        print(exponencial(1, 1))
